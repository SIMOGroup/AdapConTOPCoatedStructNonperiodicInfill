function [XYCindex,XC1,YC1,RC1,XC2,YC2,RC2,mi,nc1,nc2,ld]=mask_initial(Lx,Ly,r0,rk,bound)
%% Micro scale
%% hexagonal connect
Nx=20; Dx=Lx/Nx;           
Ny=23; Dy=2*Ly/(3*Ny+1); % odd number 
% Ny=Nx/2*tan(pi/6)*4*Ly/Lx;
nnode=2*(Ny-1)+4*Nx*(Ny-1);
XC1=zeros(nnode,1);
YC1=XC1;
mi=5*Nx*(Ny+1)/2+(Ny-1)/2*(Nx+1);
XYCindex=zeros(mi,2);
e=0;
id=[1 2 3 4 5 8];
for wj=1:(Ny+1)/2
    for wi=1:Nx
        e=e+1;
        q=[1 2 3 4]+4*(wi-1)+(wj-1)*(4*Nx+2);
        XC1(q)=[0 0.5 0.5 0]*Dx+(wi-1)*Dx;
        YC1(q)=-[0 0.5 1.5 2]*Dy-(wj-1)*3*Dy;
        index=[id(1) id(2); id(2) id(3); id(3) id(4); id(2) id(5); id(3) id(6)] +4*(wi-1)+(wj-1)*(4*Nx+2);
        XYCindex([1:5]+5*(e-1),:)=index;
        if wi==Nx
            q=[1 2]+4*Nx+(wj-1)*(4*Nx+2);
            XC1(q)=wi*Dx;
            YC1(q)=-[0 2]*Dy-(wj-1)*3*Dy;
            index=[id(1) id(2); id(2) id(3); id(3) id(4); id(2) id(5); id(3) id(6)-2] +4*(wi-1)+(wj-1)*(4*Nx+2);
            XYCindex([1:5]+5*(e-1),:)=index;
        else
        end
    end
end
e2=0;
for wj=1:(Ny-1)/2
    for wi=1:Nx+1
        e2=e2+1;       
        if wi==Nx+1
        index=[wj*(4*Nx+2) (wj+1)*(4*Nx+2)-1];
        XYCindex(5*e+e2,:)=index;
        else
        index=[4 1+(4*Nx+2)]+4*(wi-1)+(wj-1)*(4*Nx+2);
        XYCindex(5*e+e2,:)=index;
        end
    end
end
RC1=r0*ones(mi,1);
nc1=length(XC1); 
ld=Dx;% 
%% diamond connect
% Nx=30; Dx=Lx/Nx; 
% Ny=10; Dy=Ly/Ny;
% NNODE=(Nx+1)*(Ny+1);
% mi=4*Nx*Ny;     % number of micro-bars
% XCnode=0:Dx:Lx;
% YCnode=0:-Dy:-Ly;
% [XCnodemat,YCnodemat]=meshgrid(XCnode,YCnode);
% XCnodemat2=0.5*Dx+XCnodemat(1:end-1,1:end-1);
% YCnodemat2=-0.5*Dy+YCnodemat(1:end-1,1:end-1);
% XC1=[XCnodemat(:);XCnodemat2(:)];
% YC1=[YCnodemat(:);YCnodemat2(:)];
% XYCindex=zeros(mi,2);
% e=0;
% for wi=1:Nx
%     for wj=1:Ny
%         e=e+1;
%         q=[1 2 3 4]+4*(e-1); 
%         XYCindex(q,:)=  [1+wj+(wi-1)*(Ny+1) NNODE+wj+(wi-1)*Ny;
%                         Ny+2+wj+(wi-1)*(Ny+1) NNODE+wj+(wi-1)*Ny; 
%                         Ny+1+wj+(wi-1)*(Ny+1) NNODE+wj+(wi-1)*Ny; 
%                         wj+(wi-1)*(Ny+1) NNODE+wj+(wi-1)*Ny];
%     end
% end
% RC1=r0*ones(mi,1);
% nc1=length(XC1);    % numb
%% square connect
% Nx=42; Dx=Lx/Nx; 
% Ny=14; Dy=Ly/Ny;
% mi=(Nx+1)*Ny+(Ny+1)*Nx;     % number of micro-bars
% XCnode=0:Dx:Lx;
% YCnode=0:-Dy:-Ly;
% [XCnodemat,YCnodemat]=meshgrid(XCnode,YCnode);
% XC1=XCnodemat(:);
% YC1=YCnodemat(:);
% XYCindex=zeros(mi,2);
% e=0;
% for wi=1:Nx+1
%     for wj=1:Ny
%         e=e+1;
%         XYCindex(e,:)=[wj wj+1]+(wi-1)*(Ny+1);
%     end
% end
% for wj=1:Ny+1
%     for wi=1:Nx
%         e=e+1;
%         XYCindex(e,:)=[1 Ny+2]+(wi-1)*(Ny+1)+wj-1;
%     end
% end
% RC1=r0*ones(mi,1);
% nc1=length(XC1);    % number of micro-bar nodes
%% no connect
% db=0; % distance from boundary of design domain
% Nx=20; nex=1;  Dx=(Lx-2*db)/Nx; 
% Ny=10; ney=1;  Dy=(Ly-2*db)/Ny;
% nc1=nex*Nx*(Ny+1)+ney*Ny*(Nx+1);     % number of end points
% XC1=zeros(nc1,1);
% YC1=zeros(nc1,1);
% zzc=linspace(db,Lx-db,nex*Nx+1);
% yyc=-linspace(db,Ly-db,ney*Ny+1);
% for wj=1:Ny+1
% XC1([1:2:2*nex*Nx]+(wj-1)*2*nex*Nx)=zzc(1:end-1);
% XC1([2:2:2*nex*Nx]+(wj-1)*2*nex*Nx)=zzc(2:end);
% YC1([1:2*nex*Nx]+(wj-1)*2*nex*Nx)=(wj-1)*Dy+(-Ly+db);
% end
% for wi=1:Nx+1
% XC1([1:2*ney*Ny]+(wi-1)*2*ney*Ny+2*nex*Nx*(Ny+1))=(wi-1)*Dx+db;
% YC1([1:2:2*ney*Ny]+(wi-1)*2*ney*Ny+2*nex*Nx*(Ny+1))=yyc(1:end-1);
% YC1([2:2:2*ney*Ny]+(wi-1)*2*ney*Ny+2*nex*Nx*(Ny+1))=yyc(2:end);
% end
% nc1=length(XC1);
% RC1=r0*ones(nc1/2,1);
% mi=nc1/2;
% XYCindex=zeros(mi,2);
% XYCindex(:,1)=[1:2:nc1]';
% XYCindex(:,2)=[2:2:nc1]';
%% Macro bars 
% db=5; % distance from boundary of design domain
% Nx=5; nex=2;  Dx=(Lx-2*db)/Nx; 
% Ny=5; ney=2;  Dy=(Ly-2*db)/Ny;
% nc2=nex*Nx*(Ny+1)+ney*Ny*(Nx+1);     % number of end points
% XC2=zeros(nc2,1);
% YC2=zeros(nc2,1);
% zzc=linspace(db,Lx-db,nex*Nx+1);
% yyc=-linspace(db,Ly-db,ney*Ny+1);
% for wj=1:Ny+1
% XC2([1:2:2*nex*Nx]+(wj-1)*2*nex*Nx)=zzc(1:end-1);
% XC2([2:2:2*nex*Nx]+(wj-1)*2*nex*Nx)=zzc(2:end);
% YC2([1:2*nex*Nx]+(wj-1)*2*nex*Nx)=(wj-1)*Dy+(-Ly+db);
% end
% for wi=1:Nx+1
% XC2([1:2*ney*Ny]+(wi-1)*2*ney*Ny+2*nex*Nx*(Ny+1))=(wi-1)*Dx+db;
% YC2([1:2:2*ney*Ny]+(wi-1)*2*ney*Ny+2*nex*Nx*(Ny+1))=yyc(1:end-1);
% YC2([2:2:2*ney*Ny]+(wi-1)*2*ney*Ny+2*nex*Nx*(Ny+1))=yyc(2:end);
% end
% nc2=length(XC2);
% RC2=rk*ones(nc2/2,1);
% TC=t0.*ones(nc2/2,1); % thickness of hollowbar
%%
nc2=2*68;
XC2=zeros(nc2,1);
YC2=zeros(nc2,1);
XC2(1:2:end)=bound(1:end-2,1);
XC2(2:2:end)=bound(2:end-1,1);
YC2(1:2:end)=bound(1:end-2,2);
YC2(2:2:end)=bound(2:end-1,2);
RC2=rk*ones(nc2/2,1);





