function [DDC]=FDM_sensitivity(nelx,nely,Xe,Ye,edofMat,ke,nel,E0,kha,Emin,iK,jK,mask,mi,nc1,nc2,alp,XYCindex,delta,outb,p,F,U,freedofs,c)
c0=c;
DDC=zeros(1,mi+2*nc1+3*nc2);
ep=1e-4;
par=1; par1=2;par2=2;
for e=1+par*mi+par1*nc1+par2*nc2:10+par*mi+par1*nc1+par2*nc2
    mask(e)=mask(e)+ep;
    XC1=mask(1:nc1);  
    YC1=mask(1+nc1:2*nc1);
    RC1=mask(1+2*nc1:mi+2*nc1);  
    XC2=mask(1+mi+2*nc1:nc2+mi+2*nc1);  
    YC2=mask(1+nc2+mi+2*nc1:2*nc2+mi+2*nc1);
    RC2=mask(1+2*nc2+mi+2*nc1:5*nc2/2+mi+2*nc1);
    [x1,sens1,x0,sens0,X1,X0]=density(nelx,nely,Xe,Ye,XC1,YC1,RC1,XC2,YC2,RC2,mi,nc1,nc2,nel,alp,XYCindex,delta,outb);
sK = reshape(ke(:)*(Emin+X1'.^p.*(1-X0'.^p)*kha+X0'.^p.*(1-X1'.^p)),64*nel,1); 
K = sparse(iK,jK,sK); K = (K+K')/2;
U(freedofs) = K(freedofs,freedofs)\F(freedofs);
%% Sensitivites
ce = reshape(sum((U(edofMat)*ke).*U(edofMat),2),nely,nelx);
c = sum(sum((Emin+x1.^p.*(1-x0.^p)*kha+x0.^p.*(1-x1.^p)).*ce));
    c
    DDC(e)=(c-c0)/ep;
    %----------
    mask(e)=mask(e)-ep;
end
end


