alp=6;
r=3;
ep=0.05;
x=0:ep:8;
y=1./(1+exp(-alp*(x-r)));
dy=alp*exp(-alp*(x)-r).*y.^2;
dy=dy./max(abs(dy));
plot(x,y,'k',x,dy,'r','linewidth',1)
axis([0 8 -0.5 1.5])
xlabel('x')
ylabel('f(x) / df(x)')
grid on
hold on
alp=4;
r=3;
x=0:ep:8;
y=1./(1+exp(-alp*(x-r)));
dy=alp*exp(-alp*(x)-r).*y.^2;
dy=dy./max(abs(dy));
plot(x,y,'k--',x,dy,'r--','linewidth',1)

alp=8;
r=3;
x=0:ep:8;
y=1./(1+exp(-alp*(x-r)));
dy=alp*exp(-alp*(x)-r).*y.^2;
dy=dy./max(abs(dy));
plot(x,y,'k-.',x,dy,'r-.','linewidth',1)
