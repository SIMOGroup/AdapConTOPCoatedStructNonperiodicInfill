function [ke]=kemefe(nelx,nely,E0,nu,nodexy)
D=E0/(1-nu^2)*[1 nu 0;
    nu 1 0;
    0 0 (1-nu)/2];
ke=zeros(8,8);
NODEXY=[nodexy(2,:);nodexy(nely+3,:);nodexy(nely+2,:);nodexy(1,:)];
sq=sqrt(3)/3;
l=[-sq -sq; sq -sq; sq sq; -sq sq];
w=[1;1;1;1];
for q=1:4
    gausspoint=l(q,:);
    xi=gausspoint(1);
    eta=gausspoint(2);
    % Shape functions and derivatives
    H=[1/4*(1-xi)*(1-eta) 1/4*(1+xi)*(1-eta) 1/4*(1+xi)*(1+eta) 1/4*(1-xi)*(1+eta)];
    dH=1/4*[-(1-eta) 1-eta  1+eta -(1+eta); -(1-xi) -(1+xi) 1+xi  1-xi];
    % Jacobian matrix, inverse of Jacobian
    J=dH*NODEXY;
    dHxy=inv(J)*dH;
    % B matrix
    B=[dHxy(1,1) 0 dHxy(1,2) 0 dHxy(1,3) 0 dHxy(1,4) 0;
        0 dHxy(2,1) 0 dHxy(2,2) 0 dHxy(2,3) 0 dHxy(2,4);
        dHxy(2,1) dHxy(1,1) dHxy(2,2) dHxy(1,2) dHxy(2,3) dHxy(1,3) dHxy(2,4) dHxy(1,4)];
    % stiffness matrix
    ke=ke+B'*D*B*w(q)*det(J);
end

