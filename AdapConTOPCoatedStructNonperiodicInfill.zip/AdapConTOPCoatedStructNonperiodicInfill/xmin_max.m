function [xmin,xmax]=xmin_max(Lx,Ly,mi,nc1,nc2,rmax,rmin,rkmin,rkmax,XC1,YC1,XC2,YC2,ld)
db=0;   % distance form boundary of design domain
%% Micro
dd=0.25*ld;
Zmin1=XC1-dd;
Zmax1=XC1+dd;
Ymin1=YC1-dd;
Ymax1=YC1+dd;
% Zmin1=0*ones(nc1,1);
% Zmax1=Lx*ones(nc1,1);
% Ymin1=-Ly*ones(nc1,1);
% Ymax1=-0.*Ly*ones(nc1,1);
Rmin1=rmin*ones(mi,1);
Rmax1=rmax*ones(mi,1);
%% Macro
dd2=0.001;
dd3=2;
index=find(YC2<-1/3*Ly);
Zmin2=XC2-dd2;
Zmax2=XC2+dd2;
Ymin2=YC2-dd2;
Ymax2=YC2+dd2;
Zmin2(index)=XC2(index)-dd3;
Zmax2(index)=XC2(index)+dd3;
Ymin2(index)=YC2(index)-dd3;
Ymax2(index)=YC2(index)+dd3;
% Zmin2=0*ones(nc2,1)+0*db;
% Zmax2=Lx*ones(nc2,1)-0*db;
% Ymin2=-Ly*ones(nc2,1)+1*db;
% Ymax2=-0.*Ly*ones(nc2,1)-1*db;
Rmin2=rkmin*ones(nc2/2,1);
Rmax2=rkmax*ones(nc2/2,1);
%%
% xmin=[Zmin1; Ymin1; Rmin1; Zmin2; Ymin2; Rmin2];
% xmax=[Zmax1; Ymax1; Rmax1; Zmax2; Ymax2; Rmax2];
xmin=[Zmin1; Ymin1; Rmin1;Rmin2];
xmax=[Zmax1; Ymax1; Rmax1;Rmax2];
end

