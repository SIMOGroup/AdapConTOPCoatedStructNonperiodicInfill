function [x1,sens1,x0,sens0,X1,X0]=density(nelx,nely,Xe,Ye,XC1,YC1,RC1,XC2,YC2,RC2,mi,nc1,nc2,nel,alp,XYCindex,delta,outb)
%% Element density and sensitivities
[PHI1,dPHI1]=micro(nelx,nely,Xe,Ye,XC1,YC1,RC1,mi,nc1,nc2,nel,alp,XYCindex,delta);
[PHI2,dPHI2]=macro(nelx,nely,Xe,Ye,XC2,YC2,RC2,mi,nc1,nc2,nel,alp,delta);
X1=(1-PHI1).*PHI2;
X0=1-PHI2;
%
X0(outb)=0;
X1(outb)=0;

x1=reshape(X1,nely,nelx);
x0=reshape(X0,nely,nelx);
sens1=-dPHI1.*PHI2+dPHI2.*(1-PHI1);
sens0=-dPHI2;

% sens1(outb,:)=0;
% sens0(outb,:)=0;
% X1=(1-PHI1).*(1-PHI2);
% X0=PHI2.*(1-PHI3);
% %
% X0(outb)=0;
% X1(outb)=0;
% 
% x1=reshape(X1,nely,nelx);
% x0=reshape(X0,nely,nelx);
% sens1=-dPHI1.*(1-PHI2)-dPHI2.*(1-PHI1);
% sens0=dPHI2.*(1-PHI3)-dPHI3.*PHI2;