function [XC,YC,RC,TC,nc,maskb,xmaxb,xminb,mask,xmin,xmax,xold1,xold2,low,upp,n,m,a,c_mma,d]=filtering2(Lx,Ly,XC,YC,RC,TC,nc,r0,rmax,rmin,tmin,tmax,DC,c_mma)
remove=[]; 
ep=1e-4*max(abs(DC));
for wj=1:nc/2
    if (abs(DC(2*wj-1))<ep & abs(DC(2*wj))<ep & abs(DC(2*wj-1+nc))<ep & abs(DC(2*wj+nc))<ep & DC(wj+2*nc)<ep) | RC(wj)<0
    remove=[remove; 2*wj-1; 2*wj];
    else
    end
end
XC(remove)=[];YC(remove)=[]; RC(remove(2:2:end)/2)=[]; TC(remove(2:2:end)/2)=[];
nc=length(XC);
[xmin,xmax]=xmin_max(Lx,Ly,r0,nc,rmax,rmin,tmin,tmax);
%% set with negative values
% xmin(remove(2:2:end)/2+2*nc)=-10;
% xmin(remove(2:2:end)/2+2*nc+nc/2)=-5;
%%
mask=[XC;YC;RC;TC];
maskb=(mask-xmin)./(xmax-xmin);
    n=length(maskb); % number of variables x_j
    xminb=zeros(n,1);
    xmaxb=ones(n,1);
    m=2;            % number of general constraints
%     a0=1;
    a=zeros(m,1);
    c_mma=c_mma(1)*ones(m,1);
    d=zeros(m,1);
    xold1=maskb; %x(:);
    xold2=maskb; %x(:);
    low=ones(n,1);
    upp=ones(n,1);
% end