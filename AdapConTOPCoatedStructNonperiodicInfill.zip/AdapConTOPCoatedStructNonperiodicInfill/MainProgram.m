clear all
close all
% This work has been published in
%Van-Nam Hoang, Phuong Tran, Ngoc-Linh Nguyen, Klaus Hackl, H. Nguyen-Xuan, 
%Adaptive concurrent topology optimization of coated structures with nonperiodic infill for additive manufacturing
%,Computer-Aided Design, 129, 102918, 2020 https://www.sciencedirect.com/science/article/pii/S0010448520301111
%
%% Input data
sc=2;
Lx=100;     Ly=100;  
nelx=100*sc;   nely=100*sc; 
dx=Lx/nelx; dy=Ly/nely; delta=3/dx; % delta - distance from boundary to boundary of considered zone
nel=nelx*nely;      
volfrac1=0.5; volfrac0=0.125; % E0 - coating marterial
r0=0.75;       rmin=0.5;    rmax=1;      % initial thickness, lower bound and upper bound for thickness 
rk=2.12;     rkmin=1;   rkmax=5;
%% Material properties
E0=1;         % elastic modulus of base material
E1=0.3*E0;           % elastic modulus coating material
kha=E1/E0;      
Emin=1e-4;
nu=0.3;
p=2;    % penalty parameter
%% Large number
alp=3; 
loop =0; iter=0;
%% Initial Mask 
bound=importdata('bonestructure_smooth.txt');
[XYCindex,XC1,YC1,RC1,XC2,YC2,RC2,mi,nc1,nc2,ld]=mask_initial(Lx,Ly,r0,rk,bound);
% load mask
%     XC1=mask(1:nc1);  
%     XC1=mask(1:nc1);  
%     YC1=mask(1+nc1:2*nc1);
%     RC1=mask(1+2*nc1:mi+2*nc1);  
%     RC2=mask(1+mi+2*nc1:end); 

% plot_layout_component0(Lx,Ly,XYCindex,XC1,YC1,RC1,XC2,YC2,RC2,mi,nc2)
%% Coordinate, connectivity, central coordinate of elements in design domain
% poly=polyshape(bound);
% plot(poly)
[nodexy,edofMat,Xe,Ye,iK,jK,inb,outb]=connectivity(Lx,Ly,nelx,nely,dx,dy,bound);
%% density
[x1,sens1,x0,sens0,X1,X0]=density(nelx,nely,Xe,Ye,XC1,YC1,RC1,XC2,YC2,RC2,mi,nc1,nc2,nel,alp,XYCindex,delta,outb);
%% Element stiffness and FEM preparation
[ke]=kemefe(nelx,nely,E0,nu,nodexy);
ndof=2*(nelx+1)*(nely+1);     %number of degree of freedoms
F=zeros(ndof,1);       % load vector
U=zeros(ndof,1);        % displaement vector
%% Bone structure
F0=1;
lp=[15 -25-dy;72 -3-dy]; %load point
load1=(nely+1)*floor(lp(1,1)/dx)+ceil(-lp(1,2)/dy);
load2=(nely+1)*floor(lp(2,1)/dx)+ceil(-lp(2,2)/dy);
F(2*load1,1) =F0; 
F(2*load2,1) =-F0;
fixeddofs = union((nely+1)*2:2*(nely+1):2*(nelx+1)*(nely+1),(nely+1)*2-1:2*(nely+1):2*(nelx+1)*(nely+1));  
%
alldofs = 1:ndof;
freedofs = setdiff(alldofs,fixeddofs);
%% design variables
mask=[XC1;YC1;RC1;RC2];    
% mask=[XC1;YC1;RC1;XC2;YC2;RC2];  
%% START ITERATION 
    m=2;             % number of general constraints
    n=length(mask);  % number of variables x_j
    [xmin,xmax]=xmin_max(Lx,Ly,mi,nc1,nc2,rmax,rmin,rkmin,rkmax,XC1,YC1,XC2,YC2,ld);
    maskb=(mask-xmin)./(xmax-xmin);
    xminb=zeros(n,1);
    xmaxb=ones(n,1);
    xold1=maskb; 
    xold2=maskb; 
    low=ones(n,1);
    upp=ones(n,1);
    a0=1;
    a=zeros(m,1);
    c_mma=1e3*ones(m,1);    
    d=zeros(m,1);
    %-------------
change=1;
Vol=zeros(150,2);
alctr=0.993;
while change >1e-9 & loop<150
loop=loop+1;
alp=min(3+loop*(4.5-3)/50,6);
alctr=min(0.95+loop*0.03/80,0.999);
%% Filter
if ~mod(loop,1000) & loop<41 % filtering
    [XC,YC,RC,TC,nc,maskb,xmaxb,xminb,mask,xmin,xmax,xold1,xold2,low,upp,n,m,a,c_mma,d]=filtering2(Lx,Ly,XC,YC,RC,TC,nc,r0,rmax,rmin,tmin,tmax,DC,c_mma); % normailize
    iter=1;
else
    iter=iter+1;
end
[x1,sens1,x0,sens0,X1,X0]=density(nelx,nely,Xe,Ye,XC1,YC1,RC1,XC2,YC2,RC2,mi,nc1,nc2,nel,alp,XYCindex,delta,outb);
xold=maskb;
%% FEM and sensitivity analysis 
sK = reshape(ke(:)*(Emin+X1'.^p.*(1-X0'.^p)*kha+X0'.^p.*(1-X1'.^p)),64*nel,1); 
K = sparse(iK,jK,sK); K = (K+K')/2;
U(freedofs) = K(freedofs,freedofs)\F(freedofs);
%% Sensitivites
ce = reshape(sum((U(edofMat)*ke).*U(edofMat),2),nely,nelx);
c = sum(sum((Emin+x1.^p.*(1-x0.^p)*kha+x0.^p.*(1-x1.^p)).*ce));
dc1 = -(p*x1.^(p-1).*(1-x0.^p)*kha-p*x1.^(p-1).*x0.^p).*ce;
dc0=-(-p*x0.^(p-1).*x1.^p*kha+p*x0.^(p-1).*(1-x1.^p)).*ce;    
%%
vari=[1:mi+2*nc1,1+mi+2*nc1+2*nc2:mi+2*nc1+5/2*nc2];

DC=dc1(:)'*sens1(:,vari)+dc0(:)'*sens0(:,vari);     % sensitivity
DC=DC'.*(xmax-xmin);

DV1=sum(sens1(:,vari))/(length(inb)*volfrac1);
DV1=DV1.*(xmax-xmin)';
DV0=sum(sens0(:,vari))/(length(inb)*volfrac0);
DV0=DV0.*(xmax-xmin)';
%%
C(loop)=c;          % history of objective
Vol(loop,:)=[sum(X1)/length(inb),sum(X0)/length(inb)];  % history of volume fraction
%% Check sensitivites
% [DDC]=FDM_sensitivity(nelx,nely,Xe,Ye,edofMat,ke,nel,E0,kha,Emin,iK,jK,mask,mi,nc1,nc2,alp,XYCindex,delta,outb,p,F,U,freedofs,c);
% DC1=dc1(:)'*sens1+dc0(:)'*sens0; 
% par=1;
% par1=2;
% par2=2;
% dd=DC1(1+par*mi+par1*nc1+par2*nc2:10+par*mi+par1*nc1+par2*nc2)./DDC(1+par*mi+par1*nc1+par2*nc2:10+par*mi+par1*nc1+par2*nc2)
%% DESIGN UPDATE BY THE OPTIMALITY CRITERIA METHOD 
%     iter=iter+1;        % current iteration number 
    xval=maskb; 
    f0val=c;
    df0dx=DC;
    df0dx2=0*df0dx;
    fval=[sum(X1)/(length(inb)*volfrac1)-1;sum(X0)/(length(inb)*volfrac0)-1]; 
    dfdx=[DV1;DV0];
    dfdx2=0*dfdx; 
    [xmma,ymma,zmma,lam,xsi,eta,mu,zet,s,low,upp] = mmasub(m,n,iter,xval,xminb,xmaxb,xold1,xold2,f0val,df0dx,df0dx2,fval,dfdx,dfdx2,low,upp,a0,a,c_mma,d,alctr);
    maskb=xmma;
    mask=maskb.*(xmax-xmin)+xmin;
%     
    XC1=mask(1:nc1);  
    YC1=mask(1+nc1:2*nc1);
    RC1=mask(1+2*nc1:mi+2*nc1);  
    RC2=mask(1+mi+2*nc1:end); 
%     XC1=mask(1:nc1);  
%     YC1=mask(1+nc1:2*nc1);
%     RC1=mask(1+2*nc1:mi+2*nc1);  
%     XC2=mask(1+mi+2*nc1:nc2+mi+2*nc1);  
%     YC2=mask(1+nc2+mi+2*nc1:2*nc2+mi+2*nc1);
%     RC2=mask(1+2*nc2+mi+2*nc1:end);
%%
    xold2=xold1;
    xold1=maskb; %x(:);
    change = max(max(abs(maskb-xold)));  
figure(1)
axis([0 Lx -Ly 0]); axis equal
colormap(parula);
imagesc(x1+2*x0); axis equal; axis off;pause(1e-6);
disp([' It.: ' sprintf('%4i',loop) ' Obj.: ' sprintf('%10.4f',full(c)) ...
       ' Vol.: ' sprintf('%6.3f',Vol(loop,:)) ' ch.: ' sprintf('%6.3f',change) ' maxRC1.: ' sprintf('%6.3f',[max(RC1),max(RC2)])]) 
   %%
% if ~mod(loop,20) & loop<110 % filtering
% pause
% end
end 
close 2 
% plot_layout_component0(Lx,Ly,XYCindex,XC1,YC1,RC1,XC2,YC2,RC2,TC,mi,nc2)
figure(3)
plot(C,'k-','linewidth',1.5)
xlabel('Iteration')
ylabel('Objective')
axis([0 loop 80 160]);
figure(4)
plot(Vol,'linewidth',1.5)
xlabel('Iteration')
ylabel('Vol')
axis([0 loop 0 1]);



