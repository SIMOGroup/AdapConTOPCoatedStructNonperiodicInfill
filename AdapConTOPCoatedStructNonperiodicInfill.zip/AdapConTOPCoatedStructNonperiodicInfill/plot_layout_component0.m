function plot_layout_component0(Lx,Ly,XYCindex,XC1,YC1,RC1,XC2,YC2,RC2,mi,nc2)
figure(2)
hold on; axis equal; axis off
%% Micro
for wj=1:mi
    if RC1(wj)>0
        %% plot R1
        e=XYCindex(wj,:);
        phi=atan2(YC1(e(2))-YC1(e(1)),XC1(e(2))-XC1(e(1)));
        theta1 = linspace(0.5*pi+phi,phi+1.5*pi,32);
        theta2 = linspace(1.5*pi+phi,phi+2.5*pi,32);
        xx1 = RC1(wj)*cos(theta1) + XC1(e(1));
        y1 = RC1(wj)*sin(theta1) + YC1(e(1));
        xx2 = RC1(wj)*cos(theta2) + XC1(e(2));
        y2 = RC1(wj)*sin(theta2) + YC1(e(2));
        xx=[xx1 xx2 xx1(1)];
        yy=[y1 y2 y1(1)];
%         plot(xx,yy,'r-','linewidth',1)
fill(xx,yy,'c-','EdgeColor','none')
    else      
      end
end
plot([0 Lx Lx 0 0], -[0 0 Ly Ly 0], 'r--','linewidth',1.25);
for wj=1:nc2/2
    if RC2(wj)>0
        %% plot R1
        phi=atan2(YC2(2*wj)-YC2(2*wj-1),XC2(2*wj)-XC2(2*wj-1));
        theta1 = linspace(0.5*pi+phi,phi+1.5*pi,32);
        theta2 = linspace(1.5*pi+phi,phi+2.5*pi,32);
        xx1 = RC2(wj)*cos(theta1) + XC2(2*wj-1);
        y1 = RC2(wj)*sin(theta1) + YC2(2*wj-1);
        xx2 = RC2(wj)*cos(theta2) + XC2(2*wj);
        y2 = RC2(wj)*sin(theta2) + YC2(2*wj);
        xx=[xx1 xx2 xx1(1)];
        yy=[y1 y2 y1(1)];
        plot(xx,yy,'b-','linewidth',1)
    else
        
      end
end
