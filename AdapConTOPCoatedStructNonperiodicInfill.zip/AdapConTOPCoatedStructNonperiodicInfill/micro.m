function [PHI1,dPHI1]=micro(nelx,nely,Xe,Ye,XC1,YC1,RC1,mi,nc1,nc2,nel,alp,XYCindex,delta)
%% Micro
xxc=XC1(XYCindex(:,2))-XC1(XYCindex(:,1));
yyc=YC1(XYCindex(:,2))-YC1(XYCindex(:,1));
le=sqrt(xxc.^2+yyc.^2);     % component length
p=xxc./le;      % cosine
q=yyc./le;      % sine
% Local coordinate
xi=p.*XC1(XYCindex(:,1))+q.*YC1(XYCindex(:,1));   % xi bar
yi=-q.*XC1(XYCindex(:,1))+p.*YC1(XYCindex(:,1));
xj=p.*XC1(XYCindex(:,2))+q.*YC1(XYCindex(:,2));
yj=-q.*XC1(XYCindex(:,2))+p.*YC1(XYCindex(:,2));
de=zeros(nel,1); dedXi=de;dedYi=de;dedXj=de;dedYj=de;
pai1=ones(nel,mi);
dPHI1=zeros(nel,mi+2*nc1+5/2*nc2);
for wj=1:mi
    ei=XYCindex(wj,1);ej=XYCindex(wj,2);
    % derivative of p, q with respect to Xi,Yi,Xj,Yj (end points)
    dpdXi=(-le(wj)^2+(XC1(ej)-XC1(ei))*(XC1(ej)-XC1(ei)))/le(wj)^3;
    dpdYi=(XC1(ej)-XC1(ei))*(YC1(ej)-YC1(ei))/le(wj)^3;
    dpdXj=-dpdXi;
    dpdYj=-dpdYi;
    dqdXi=(YC1(ej)-YC1(ei))*(XC1(ej)-XC1(ei))/le(wj)^3;
    dqdYi=(-le(wj)^2+(YC1(ej)-YC1(ei))*(YC1(ej)-YC1(ei)))/le(wj)^3;
    dqdXj=-dqdXi;
    dqdYj=-dqdYi;
    % derivative of local coordinate xi,yi,xj,yj with respect to Xi,Yi,Xj,Yj
    dxidXi=p(wj)+XC1(ei)*dpdXi+YC1(ei)*dqdXi;
    dxidYi=q(wj)+XC1(ei)*dpdYi+YC1(ei)*dqdYi;
    dxidXj=      XC1(ei)*dpdXj+YC1(ei)*dqdXj;
    dxidYj=      XC1(ei)*dpdYj+YC1(ei)*dqdYj;
    %---------------------------------------------
    dyidXi=-q(wj)-XC1(ei)*dqdXi+YC1(ei)*dpdXi;
    dyidYi= p(wj)-XC1(ei)*dqdYi+YC1(ei)*dpdYi;
    dyidXj=      -XC1(ei)*dqdXj+YC1(ei)*dpdXj;
    dyidYj=      -XC1(ei)*dqdYj+YC1(ei)*dpdYj;
    %---------------------------------------------
    dxjdXi=      XC1(ej)*dpdXi+YC1(ej)*dqdXi;
    dxjdYi=      XC1(ej)*dpdYi+YC1(ej)*dqdYi;
    dxjdXj=p(wj)+XC1(ej)*dpdXj+YC1(ej)*dqdXj;
    dxjdYj=q(wj)+XC1(ej)*dpdYj+YC1(ej)*dqdYj;
    %---------------------------------------------
    dyjdXi=      -XC1(ej)*dqdXi+YC1(ej)*dpdXi;
    dyjdYi=      -XC1(ej)*dqdYi+YC1(ej)*dpdYi;
    dyjdXj=-q(wj)-XC1(ej)*dqdXj+YC1(ej)*dpdXj;
    dyjdYj= p(wj)-XC1(ej)*dqdYj+YC1(ej)*dpdYj;
    %
    xe=p(wj)*Xe+q(wj)*Ye;         % element coordinate xe in local coordinate systems
    ye=-q(wj)*Xe+p(wj)*Ye;
    dxedXi=Xe*dpdXi+Ye*dqdXi;     % derivative of xe with respect to Xi,Yi,Xj,Yj
    dxedYi=Xe*dpdYi+Ye*dqdYi;
    dxedXj=Xe*dpdXj+Ye*dqdXj;
    dxedYj=Xe*dpdYj+Ye*dqdYj;
    %
    dyedXi=-Xe*dqdXi+Ye*dpdXi;     % derivative of ye with respect to Xi,Yi,Xj,Yj
    dyedYi=-Xe*dqdYi+Ye*dpdYi;
    dyedXj=-Xe*dqdXj+Ye*dpdXj;
    dyedYj=-Xe*dqdYj+Ye*dpdYj;
    %
    yiye=yi(wj)-ye;
    de=abs(yiye);
    edof_left=find(xe<xi(wj)&xe>xi(wj)-delta-RC1(wj));
    edof_right=find(xe>xj(wj)&xe<xj(wj)+delta+RC1(wj));
    edof_mid=find(xe>=xi(wj)&xe<=xj(wj)&de<max(RC1(wj)+delta,delta));
    edofin=[edof_left;edof_right;edof_mid]; % element in considered zone
    yiye_sign=sign(yiye(edof_mid));
    dedXi(edof_mid)=yiye_sign.*(dyidXi-dyedXi(edof_mid));
    dedYi(edof_mid)=yiye_sign.*(dyidYi-dyedYi(edof_mid));
    dedXj(edof_mid)=yiye_sign.*(dyidXj-dyedXj(edof_mid));
    dedYj(edof_mid)=yiye_sign.*(dyidYj-dyedYj(edof_mid));
    if length(edof_left)>0
        de(edof_left)=sqrt((xi(wj)-xe(edof_left)).^2+(yi(wj)-ye(edof_left)).^2);
        dedxib1=(xi(wj)-xe(edof_left))./de(edof_left);
        dedyib1=(yi(wj)-ye(edof_left))./de(edof_left);
        dedxeb1=-(xi(wj)-xe(edof_left))./de(edof_left);
        dedyeb1=-(yi(wj)-ye(edof_left))./de(edof_left);
        dedXi(edof_left)=dedxib1*dxidXi+dedyib1*dyidXi+dedxeb1.*dxedXi(edof_left)+dedyeb1.*dyedXi(edof_left);
        dedYi(edof_left)=dedxib1*dxidYi+dedyib1*dyidYi+dedxeb1.*dxedYi(edof_left)+dedyeb1.*dyedYi(edof_left);
        dedXj(edof_left)=dedxib1*dxidXj+dedyib1*dyidXj+dedxeb1.*dxedXj(edof_left)+dedyeb1.*dyedXj(edof_left);
        dedYj(edof_left)=dedxib1*dxidYj+dedyib1*dyidYj+dedxeb1.*dxedYj(edof_left)+dedyeb1.*dyedYj(edof_left);
    else
    end
    if length(edof_right)>0
        de(edof_right)=sqrt((xj(wj)-xe(edof_right)).^2+(yj(wj)-ye(edof_right)).^2);
        dedxib2=(xj(wj)-xe(edof_right))./de(edof_right);
        dedyib2=(yj(wj)-ye(edof_right))./de(edof_right);
        dedxeb2=-(xj(wj)-xe(edof_right))./de(edof_right);
        dedyeb2=-(yj(wj)-ye(edof_right))./de(edof_right);
        dedXi(edof_right)=dedxib2*dxjdXi+dedyib2*dyjdXi+dedxeb2.*dxedXi(edof_right)+dedyeb2.*dyedXi(edof_right);
        dedYi(edof_right)=dedxib2*dxjdYi+dedyib2*dyjdYi+dedxeb2.*dxedYi(edof_right)+dedyeb2.*dyedYi(edof_right);
        dedXj(edof_right)=dedxib2*dxjdXj+dedyib2*dyjdXj+dedxeb2.*dxedXj(edof_right)+dedyeb2.*dyedXj(edof_right);
        dedYj(edof_right)=dedxib2*dxjdYj+dedyib2*dyjdYj+dedxeb2.*dxedYj(edof_right)+dedyeb2.*dyedYj(edof_right);
    else
    end
    phi1=1./(1+exp(-alp*(de(edofin)-RC1(wj))));
    pai1(edofin,wj)=phi1;
    %%
    dphi1dek=alp.*exp(-alp*(de(edofin)-RC1(wj))).*phi1;
    dPHI1(edofin,ei)=dPHI1(edofin,ei)+dphi1dek.*dedXi(edofin);
    dPHI1(edofin,ei+nc1)=dPHI1(edofin,ei+nc1)+dphi1dek.*dedYi(edofin);
    dPHI1(edofin,ej)=dPHI1(edofin,ej)+dphi1dek.*dedXj(edofin);
    dPHI1(edofin,ej+nc1)=dPHI1(edofin,ej+nc1)+dphi1dek.*dedYj(edofin);
    dPHI1(edofin,wj+2*nc1)=dPHI1(edofin,wj+2*nc1)-dphi1dek;
end
% %
PHI1=prod(pai1,2); % PAI2
dPHI1=PHI1.*dPHI1;