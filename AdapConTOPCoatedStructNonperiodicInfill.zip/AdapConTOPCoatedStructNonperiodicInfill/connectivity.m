function [nodexy,edofMat,Xe,Ye,iK,jK,inb,outb]=connectivity(Lx,Ly,nelx,nely,dx,dy,bound)
%% Coordinate and connectivity
nodenrs = reshape(1:(1+nelx)*(1+nely),1+nely,1+nelx);
edofVec = reshape(2*nodenrs(1:end-1,1:end-1)+1,nelx*nely,1);
edofMat = repmat(edofVec,1,8)+repmat([0 1 2*nely+[2 3 0 1] -2 -1],nelx*nely,1);
iK = reshape(kron(edofMat,ones(8,1))',64*nelx*nely,1);
jK = reshape(kron(edofMat,ones(1,8))',64*nelx*nely,1);
Xnode=0:dx:Lx;
Ynode=0:-dy:-Ly;
[Xnodemat,Ynodemat]=meshgrid(Xnode,Ynode);
nodexy=zeros((1+nelx)*(1+nely),2);
nodexy(:,1)=Xnodemat(:);
nodexy(:,2)=Ynodemat(:);
%% Coordinate of central elements
Xemat=0.5*dx+Xnodemat(1:end-1,1:end-1);
Yemat=-0.5*dy+Ynodemat(1:end-1,1:end-1);
Xe=Xemat(:);
Ye=Yemat(:);
%% Define design domain
inbindex = inpolygon(Xe,Ye,bound(:,1),bound(:,2));
inb=find(inbindex~=0);
outb=setdiff([1:nely*nelx],inb);
